"use client";

import { useState } from "react";
import Link from "next/link";
import {
  Shield, Zap, Brain, BookOpen, ArrowRight, CheckCircle, ChevronRight,
  Upload, ScanLine, AlertTriangle, LifeBuoy, Github, Linkedin, Mail,
  Plus, Minus, ExternalLink
} from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { cn } from "@/lib/utils";

/* ── DATA ── */
const pillars = [
  { icon: "🛡️", iconBg: "rgba(59,130,246,0.12)", title: "Shield", sub: "Real-time scam detection" },
  { icon: "🧠", iconBg: "rgba(124,58,237,0.12)", title: "Understand", sub: "Psychology analysis" },
  { icon: "💚", iconBg: "rgba(14,165,233,0.12)", title: "Recover", sub: "Step-by-step guidance" },
  { icon: "📚", iconBg: "rgba(34,197,94,0.12)", title: "Educate", sub: "Build scam resistance" },
];

const features = [
  {
    icon: <Zap className="w-5 h-5 text-blue-400" />,
    iconBg: "rgba(59,130,246,0.1)",
    title: "1.4s AI Analysis",
    description: "Upload any screenshot, message, or document. Kavach detects scam patterns across 4.2M threat signatures in under 2 seconds.",
  },
  {
    icon: <Brain className="w-5 h-5 text-violet-400" />,
    iconBg: "rgba(124,58,237,0.1)",
    title: "Psychological Decoding",
    description: "Understand exactly which manipulation tactics — urgency, authority, fear, greed — are being weaponized against you.",
  },
  {
    icon: <BookOpen className="w-5 h-5 text-sky-400" />,
    iconBg: "rgba(14,165,233,0.1)",
    title: "Recovery Guidance",
    description: "If you've been scammed, Kavach provides structured, compassionate guidance to minimize loss and report to authorities.",
  },
  {
    icon: <Shield className="w-5 h-5 text-emerald-400" />,
    iconBg: "rgba(34,197,94,0.1)",
    title: "Scam Intelligence Map",
    description: "See how scam networks are structured — from the initial contact to the final extraction mechanism.",
  },
];

const stats = [
  { value: "₹11,333 Cr", label: "Cyber fraud losses in India (2023)" },
  { value: "4.2M+", label: "Scam patterns in our database" },
  { value: "94%", label: "Detection accuracy" },
  { value: "1.4s", label: "Average analysis time" },
];

const scamTypes = [
  { label: "KYC / Account Freeze Scam", tag: "Most Common", color: "#EF4444" },
  { label: "Fake Job Offer Scam", tag: "Rising", color: "#F97316" },
  { label: "UPI / Payment Fraud", tag: "High Risk", color: "#EF4444" },
  { label: "Loan Shark Scam", tag: "Growing", color: "#F59E0B" },
  { label: "Romance / Investment Scam", tag: "Complex", color: "#A78BFA" },
  { label: "OTP Phishing", tag: "Common", color: "#EF4444" },
];

const howItWorks = [
  {
    step: "01",
    icon: <Upload className="w-6 h-6 text-blue-400" />,
    iconBg: "rgba(59,130,246,0.12)",
    title: "Upload Content",
    description: "Drop a screenshot, paste a suspicious message, or submit a URL. Kavach accepts any format — WhatsApp, email, SMS, or social media.",
    tag: "Any format",
    tagColor: "rgba(59,130,246,0.15)",
    tagText: "#60A5FA",
  },
  {
    step: "02",
    icon: <ScanLine className="w-6 h-6 text-violet-400" />,
    iconBg: "rgba(124,58,237,0.12)",
    title: "AI Analysis",
    description: "Our engine scans against 4.2M scam signatures, checks linguistic patterns, and cross-references known fraud networks in under 2 seconds.",
    tag: "< 2 seconds",
    tagColor: "rgba(124,58,237,0.15)",
    tagText: "#A78BFA",
  },
  {
    step: "03",
    icon: <Brain className="w-6 h-6 text-sky-400" />,
    iconBg: "rgba(14,165,233,0.12)",
    title: "Psychology Detection",
    description: "Kavach exposes the psychological manipulation tactics being used — urgency, authority impersonation, fear triggers, and false scarcity.",
    tag: "Deep insights",
    tagColor: "rgba(14,165,233,0.15)",
    tagText: "#38BDF8",
  },
  {
    step: "04",
    icon: <LifeBuoy className="w-6 h-6 text-emerald-400" />,
    iconBg: "rgba(34,197,94,0.12)",
    title: "Recovery Guidance",
    description: "Get a personalized, step-by-step action plan. From blocking the scammer to filing an official report with CERT-In or your bank.",
    tag: "Actionable steps",
    tagColor: "rgba(34,197,94,0.15)",
    tagText: "#34D399",
  },
];

const whyItMatters = [
  {
    number: "₹10,000+",
    unit: "Cr",
    label: "Lost to cyber fraud yearly",
    detail: "India reported over ₹11,333 crore in cyber fraud losses in 2023 alone — a 200% increase from 2019.",
    color: "#EF4444",
  },
  {
    number: "7,000",
    unit: "+",
    label: "Scam complaints daily",
    detail: "The National Cyber Crime Reporting Portal receives over 7,000 scam-related complaints every single day.",
    color: "#F97316",
  },
  {
    number: "72%",
    unit: "",
    label: "Victims don't report",
    detail: "Nearly three-quarters of scam victims never report — due to shame, confusion, or not knowing where to turn.",
    color: "#A78BFA",
  },
  {
    number: "94%",
    unit: "",
    label: "Kavach detection rate",
    detail: "Our AI correctly identifies scam attempts in 94% of cases — giving you the clarity you need before it's too late.",
    color: "#34D399",
  },
];

const faqs = [
  {
    q: "How accurate is Kavach at detecting scams?",
    a: "Kavach achieves 94% accuracy across tested scam categories. It's trained on 4.2 million threat signatures spanning WhatsApp scams, phishing emails, fake payment alerts, job fraud, and more. Accuracy is highest with full screenshots that include sender details.",
  },
  {
    q: "Can Kavach analyze screenshots?",
    a: "Yes — screenshots are the most accurate input method. Upload PNG, JPG, WEBP, or PDF. Kavach uses OCR to extract text and visual analysis to detect brand impersonation, fake UI elements, and spoofed sender names.",
  },
  {
    q: "Can Kavach detect WhatsApp scams?",
    a: "Absolutely. WhatsApp is the #1 vector for scams in India. Screenshot a suspicious message and upload it — Kavach will identify the scam type, decode the psychological tactics, and tell you exactly what to do next.",
  },
  {
    q: "Is my data stored or shared?",
    a: "No. Kavach processes your content in memory only — nothing is logged, stored, or shared. Analysis is ephemeral by design. We don't build profiles, we don't use your data for training, and we never share it with third parties.",
  },
  {
    q: "What if I already shared my OTP or bank details?",
    a: "Act immediately. Kavach's Recovery Guidance section provides step-by-step instructions: call your bank's 24/7 fraud helpline, freeze your account, file a complaint on cybercrime.gov.in, and contact CERT-In. Time is critical — every minute matters.",
  },
  {
    q: "Can Kavach analyze suspicious URLs?",
    a: "Yes. Paste any URL — including shortened links like bit.ly — and Kavach will check it against known phishing domains, analyze the URL structure for deception patterns, and simulate what the destination might look like without you visiting it.",
  },
];

/* ── LIVE PREVIEW COMPONENT ── */
function LivePreview() {
  const [step, setStep] = useState<"idle" | "analyzing" | "result">("idle");
  const [progress, setProgress] = useState(0);
  const [inputValue, setInputValue] = useState("");

  const exampleMessage = "Dear Customer, Your SBI account KYC is pending. Failure to update in 24hrs will result in account suspension. Update now: bit.ly/sbi-kyc-update";

  const runDemo = async () => {
    if (step === "analyzing") return;
    setInputValue(exampleMessage);
    setStep("analyzing");
    setProgress(0);
    const steps = [15, 35, 60, 80, 95, 100];
    for (const p of steps) {
      await new Promise((r) => setTimeout(r, 250));
      setProgress(p);
    }
    setStep("result");
  };

  const reset = () => {
    setStep("idle");
    setProgress(0);
    setInputValue("");
  };

  return (
    <div className="w-full max-w-[640px] mx-auto">
      <div className="bg-[#060B18] border border-[#1E2A45] rounded-[20px] overflow-hidden shadow-[0_0_60px_rgba(37,99,235,0.08)]">
        {/* Window bar */}
        <div className="flex items-center gap-2 px-4 py-3 bg-[#080E1C] border-b border-[#1E2A45]">
          <div className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
          <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" />
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/70" />
          <span className="ml-2 text-[10px] text-slate-600 font-medium">kavach.ai — Live Demo</span>
          <div className="ml-auto flex items-center gap-1.5 text-[9px] text-emerald-400 font-semibold">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse-green" />
            AI Active
          </div>
        </div>

        <div className="p-5">
          {step === "idle" && (
            <div>
              <p className="text-[11px] text-slate-500 mb-2 font-medium uppercase tracking-[0.07em]">Paste suspicious message</p>
              <div className="relative">
                <textarea
                  readOnly
                  value={inputValue || "Try our live demo — click Analyze below..."}
                  rows={3}
                  className="w-full bg-white/[0.04] border border-[#1E2A45] rounded-[10px] p-3 text-[12px] text-slate-400 resize-none outline-none leading-relaxed cursor-pointer"
                  onClick={runDemo}
                />
              </div>
              <button onClick={runDemo}
                className="w-full mt-3 h-[40px] gradient-kavach rounded-[10px] text-[12px] font-bold text-white flex items-center justify-center gap-2 transition-all hover:-translate-y-px hover:shadow-[0_4px_20px_rgba(124,58,237,0.4)]">
                <Shield className="w-4 h-4" /> Analyze with Kavach AI
              </button>
              <p className="text-center text-[10px] text-slate-600 mt-2">Uses a real scam example · No data stored</p>
            </div>
          )}

          {step === "analyzing" && (
            <div className="py-6 text-center">
              <div className="relative w-14 h-14 mx-auto mb-4">
                <div className="absolute inset-0 rounded-full border border-blue-400/20 animate-spin-slow" />
                <div className="absolute inset-0 rounded-full border border-violet-400/15 animate-spin-slow-r" />
                <div className="absolute inset-0 flex items-center justify-center animate-breathe">
                  <div className="w-9 h-9 gradient-kavach rounded-[10px] flex items-center justify-center">
                    <Shield className="w-5 h-5 text-white" strokeWidth={1.5} />
                  </div>
                </div>
              </div>
              <p className="text-[13px] font-bold text-white mb-1">Kavach AI Analyzing</p>
              <p className="text-[11px] text-slate-500 mb-4">Scanning 4.2M threat patterns...</p>
              <div className="w-full bg-white/[0.07] rounded-full h-1.5 overflow-hidden">
                <div className="h-full gradient-kavach rounded-full transition-all duration-300" style={{ width: `${progress}%` }} />
              </div>
              <p className="text-[10px] text-blue-400 mt-1.5 font-semibold">{progress}%</p>
            </div>
          )}

          {step === "result" && (
            <div>
              <div className="flex items-center gap-3 p-3 rounded-[12px] bg-red-500/[0.08] border border-red-500/25 mb-3">
                <div className="w-10 h-10 rounded-[10px] bg-red-500/15 flex items-center justify-center flex-shrink-0">
                  <AlertTriangle className="w-5 h-5 text-red-400" />
                </div>
                <div>
                  <p className="text-[13px] font-black text-white">SCAM DETECTED</p>
                  <p className="text-[11px] text-red-400">KYC Phishing Attack · Risk Score: 94/100</p>
                </div>
                <div className="ml-auto text-[24px] font-black text-red-400 leading-none">94</div>
              </div>
              <div className="grid grid-cols-2 gap-2 mb-3">
                {[
                  { icon: "🚨", label: "Urgency Trigger", desc: "24-hour deadline pressure" },
                  { icon: "🎭", label: "Brand Impersonation", desc: "Fake SBI branding" },
                  { icon: "🔗", label: "Malicious URL", desc: "Shortened phishing link" },
                  { icon: "😰", label: "Fear Manipulation", desc: "Account suspension threat" },
                ].map((flag) => (
                  <div key={flag.label} className="p-2.5 rounded-[8px] bg-white/[0.03] border border-white/[0.07]">
                    <p className="text-[11px] text-white font-semibold mb-0.5">{flag.icon} {flag.label}</p>
                    <p className="text-[10px] text-slate-500">{flag.desc}</p>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <button onClick={reset}
                  className="flex-1 h-[34px] bg-white/[0.05] border border-white/[0.1] rounded-[8px] text-[11px] text-slate-400 font-medium transition-all hover:bg-white/[0.08]">
                  Try Again
                </button>
                <Link href="/results" className="flex-1">
                  <button className="w-full h-[34px] gradient-kavach rounded-[8px] text-[11px] text-white font-bold transition-all hover:shadow-[0_4px_16px_rgba(124,58,237,0.4)] flex items-center justify-center gap-1">
                    Full Report <ChevronRight className="w-3 h-3" />
                  </button>
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ── FAQ ITEM ── */
function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div
      className={cn(
        "border rounded-[14px] transition-all duration-300 overflow-hidden cursor-pointer",
        open ? "border-blue-500/30 bg-blue-600/[0.04]" : "border-[#1E2A45] bg-white/[0.02] hover:border-blue-500/20"
      )}
      onClick={() => setOpen(!open)}
    >
      <div className="flex items-center justify-between px-5 py-4 gap-4">
        <span className="text-[13px] font-semibold text-white leading-snug">{q}</span>
        <div className={cn(
          "w-6 h-6 rounded-full border flex items-center justify-center flex-shrink-0 transition-all",
          open ? "border-blue-400/50 bg-blue-600/15 text-blue-400" : "border-white/15 text-slate-500"
        )}>
          {open ? <Minus className="w-3 h-3" /> : <Plus className="w-3 h-3" />}
        </div>
      </div>
      {open && (
        <div className="px-5 pb-4">
          <p className="text-[12px] text-slate-400 leading-relaxed">{a}</p>
        </div>
      )}
    </div>
  );
}

/* ── PAGE ── */
export default function HomePage() {
  return (
    <div className="min-h-screen bg-[#060B18]">
      <Navbar />

      {/* ── HERO ── */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute grid-overlay inset-0" />
          <div className="absolute -top-[80px] left-1/2 -translate-x-1/2 w-[600px] h-[400px] rounded-full animate-glow-pulse"
            style={{ background: "radial-gradient(ellipse, rgba(30,64,175,0.16) 0%, transparent 65%)" }} />
          <div className="absolute -bottom-[40px] right-10 w-[300px] h-[300px] rounded-full"
            style={{ background: "radial-gradient(ellipse, rgba(124,58,237,0.1) 0%, transparent 65%)" }} />
        </div>

        <div className="relative z-10 flex flex-col items-center text-center pt-14 pb-12 px-8">
          <div className="inline-flex items-center gap-2 bg-blue-600/10 border border-blue-600/22 rounded-full px-3.5 py-1.5 text-[11px] font-semibold text-blue-300 tracking-[0.06em] mb-5 animate-fade-slide">
            <span className="w-[5px] h-[5px] rounded-full bg-emerald-400 animate-pulse-green" />
            AI-Powered Scam Protection · Live
          </div>

          <div className="flex items-center justify-center gap-6 mb-7 relative z-10">
            <div className="hidden md:flex flex-col gap-2">
              <div className="bg-[rgba(8,14,30,0.92)] border border-[#1E2A45] rounded-[9px] px-3 py-2 min-w-[110px]">
                <div className="text-[9px] font-semibold text-slate-500 tracking-[0.07em] uppercase mb-1">Threats Today</div>
                <div className="text-[12px] font-bold text-white flex items-center gap-1">
                  <span className="w-[5px] h-[5px] rounded-full bg-red-500" />1,247 blocked
                </div>
              </div>
              <div className="bg-[rgba(8,14,30,0.92)] border border-[#1E2A45] rounded-[9px] px-3 py-2 min-w-[110px]">
                <div className="text-[9px] font-semibold text-slate-500 tracking-[0.07em] uppercase mb-1">Accuracy</div>
                <div className="text-[12px] font-bold text-white flex items-center gap-1">
                  <span className="w-[5px] h-[5px] rounded-full bg-emerald-400" />94.7%
                </div>
              </div>
            </div>

            <div className="relative w-[140px] h-[140px] flex items-center justify-center flex-shrink-0">
              <div className="absolute w-[120px] h-[120px] rounded-full border border-blue-400/15 animate-spin-slow" />
              <div className="absolute w-[140px] h-[140px] rounded-full border border-violet-400/10 animate-spin-slow-r" />
              <div className="animate-breathe z-10">
                <div className="w-[72px] h-[72px] gradient-kavach rounded-[18px] flex items-center justify-center shadow-[0_8px_32px_rgba(59,130,246,0.4)]">
                  <Shield className="w-9 h-9 text-white" strokeWidth={1.5} />
                </div>
              </div>
            </div>

            <div className="hidden md:flex flex-col gap-2">
              <div className="bg-[rgba(8,14,30,0.92)] border border-[#1E2A45] rounded-[9px] px-3 py-2 min-w-[110px]">
                <div className="text-[9px] font-semibold text-slate-500 tracking-[0.07em] uppercase mb-1">Response</div>
                <div className="text-[12px] font-bold text-white">1.4s avg</div>
              </div>
              <div className="bg-[rgba(8,14,30,0.92)] border border-[#1E2A45] rounded-[9px] px-3 py-2 min-w-[110px]">
                <div className="text-[9px] font-semibold text-slate-500 tracking-[0.07em] uppercase mb-1">Database</div>
                <div className="text-[12px] font-bold text-white">4.2M patterns</div>
              </div>
            </div>
          </div>

          <h1 className="text-[44px] md:text-[52px] font-black leading-[1.06] tracking-[-0.035em] text-white max-w-[640px] mb-4">
            See Through the Scam.<br />
            <span className="gradient-text animate-shimmer">Stay Protected.</span>
          </h1>
          <p className="text-[15px] text-slate-400 leading-relaxed max-w-[480px] mb-7">
            Kavach analyzes screenshots, messages, and documents to expose scam tactics, decode psychological manipulation, and guide you to safety.
          </p>

          <div className="flex gap-2.5 justify-center mb-6">
            <Link href="/analyze">
              <button className="h-[44px] px-7 gradient-kavach rounded-[10px] text-[14px] font-black text-white flex items-center gap-2 transition-all hover:-translate-y-px hover:shadow-[0_6px_24px_rgba(124,58,237,0.4)]">
                Analyze a Scam <ArrowRight className="w-4 h-4" />
              </button>
            </Link>
            <Link href="/results">
              <button className="h-[44px] px-5 bg-white/[0.05] border border-white/[0.1] rounded-[10px] text-[14px] font-medium text-white flex items-center gap-2 transition-all hover:bg-white/[0.08]">
                See Sample Analysis
              </button>
            </Link>
          </div>

          <div className="flex gap-5 flex-wrap justify-center">
            {["100% Free", "No Sign-up Required", "Privacy First", "Made in India 🇮🇳"].map((t) => (
              <div key={t} className="flex items-center gap-1.5 text-[11px] text-slate-500">
                <CheckCircle className="w-3 h-3 text-emerald-400" />{t}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PILLARS ── */}
      <section className="bg-[#080E1C] border-y border-[#101828] py-3.5">
        <div className="flex justify-center flex-wrap gap-0">
          {pillars.map((p, i) => (
            <div key={p.title} className={`flex items-center gap-2.5 px-6 py-2.5 ${i < pillars.length - 1 ? "border-r border-[#111827]" : ""}`}>
              <div className="w-[30px] h-[30px] rounded-[7px] flex items-center justify-center text-[14px] flex-shrink-0" style={{ background: p.iconBg }}>
                {p.icon}
              </div>
              <div>
                <div className="text-[12px] font-bold text-white">{p.title}</div>
                <div className="text-[10px] text-slate-500 mt-0.5">{p.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── STATS ── */}
      <section className="bg-[#0A101F] border-b border-[#101828] py-10 px-8">
        <div className="max-w-[860px] mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
          {stats.map((s) => (
            <div key={s.value} className="text-center">
              <div className="text-[28px] font-black text-white tracking-tight gradient-text animate-shimmer mb-1">{s.value}</div>
              <div className="text-[11px] text-slate-500">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── HOW IT WORKS ── */}
      <section className="py-16 px-8 bg-[#060B18] border-b border-[#101828]">
        <div className="max-w-[920px] mx-auto">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-1.5 bg-violet-600/10 border border-violet-600/25 rounded-full px-3 py-1 text-[10px] font-bold text-violet-300 tracking-[0.07em] uppercase mb-3">
              <Zap className="w-3 h-3" /> How It Works
            </div>
            <h2 className="text-[30px] font-black tracking-[-0.025em] text-white mb-2.5">
              From Upload to<br />
              <span className="gradient-text">Full Clarity</span>
            </h2>
            <p className="text-[13px] text-slate-500 leading-relaxed max-w-[420px] mx-auto">
              Four steps. Two seconds. Complete understanding of any scam attempt.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {howItWorks.map((step, i) => (
              <div key={step.step} className="relative p-5 bg-[#080E1C] border border-[#1E2A45] rounded-[16px] hover:border-blue-500/25 hover:-translate-y-0.5 transition-all group">
                {/* connector line */}
                {i < howItWorks.length - 1 && (
                  <div className="hidden lg:block absolute -right-2 top-1/2 -translate-y-1/2 z-10">
                    <ChevronRight className="w-4 h-4 text-slate-700" />
                  </div>
                )}
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-[11px] flex items-center justify-center" style={{ background: step.iconBg }}>
                    {step.icon}
                  </div>
                  <span className="text-[28px] font-black text-white/[0.06] leading-none">{step.step}</span>
                </div>
                <h3 className="text-[13px] font-bold text-white mb-2">{step.title}</h3>
                <p className="text-[11px] text-slate-500 leading-relaxed mb-3">{step.description}</p>
                <span className="inline-flex items-center text-[10px] font-semibold px-2.5 py-1 rounded-full" style={{ color: step.tagText, background: step.tagColor }}>
                  {step.tag}
                </span>
              </div>
            ))}
          </div>

          <div className="mt-8 text-center">
            <Link href="/analyze">
              <button className="h-[44px] px-8 gradient-kavach rounded-[11px] text-[13px] font-bold text-white inline-flex items-center gap-2 transition-all hover:-translate-y-px hover:shadow-[0_6px_24px_rgba(124,58,237,0.4)]">
                Try It Now <ArrowRight className="w-4 h-4" />
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* ── WHY IT MATTERS ── */}
      <section className="py-16 px-8 bg-[#0A101F] border-b border-[#101828]">
        <div className="max-w-[920px] mx-auto">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-1.5 bg-red-600/10 border border-red-600/25 rounded-full px-3 py-1 text-[10px] font-bold text-red-300 tracking-[0.07em] uppercase mb-3">
              <AlertTriangle className="w-3 h-3" /> Why It Matters
            </div>
            <h2 className="text-[30px] font-black tracking-[-0.025em] text-white mb-2.5">
              India&apos;s Cyber Fraud Crisis<br />
              <span className="gradient-text">Is Getting Worse</span>
            </h2>
            <p className="text-[13px] text-slate-500 leading-relaxed max-w-[520px] mx-auto">
              Every day, thousands of Indians lose money, dignity, and trust to digital scammers. Most victims had no way to verify the threat before it was too late.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
            {whyItMatters.map((item) => (
              <div key={item.label} className="p-5 bg-[#060B18] border border-[#1E2A45] rounded-[16px] text-center hover:border-opacity-60 transition-all"
                style={{ borderColor: `${item.color}20` }}>
                <div className="text-[36px] font-black leading-none mb-1" style={{ color: item.color }}>
                  {item.number}<span className="text-[20px]">{item.unit}</span>
                </div>
                <p className="text-[11px] font-bold text-white mb-2">{item.label}</p>
                <p className="text-[10px] text-slate-600 leading-relaxed">{item.detail}</p>
              </div>
            ))}
          </div>

          <div className="p-6 bg-[#060B18] border border-blue-500/15 rounded-[18px] text-center">
            <p className="text-[15px] font-bold text-white mb-2">
              The solution isn&apos;t better laws — it&apos;s better awareness.
            </p>
            <p className="text-[12px] text-slate-400 leading-relaxed max-w-[600px] mx-auto mb-4">
              Kavach was built on a single belief: if people could see a scam for what it really is — a set of predictable psychological tricks — they would never fall for it. Education is the strongest shield.
            </p>
            <div className="flex items-center justify-center gap-2 text-[11px] text-emerald-400">
              <CheckCircle className="w-4 h-4" />
              Free for every Indian · No barriers · No excuses
            </div>
          </div>
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section className="bg-[#0A101F] py-14 px-8 border-b border-[#101828]">
        <div className="max-w-[900px] mx-auto">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-1.5 bg-blue-600/10 border border-blue-600/22 rounded-full px-3 py-1 text-[10px] font-bold text-blue-300 tracking-[0.07em] uppercase mb-3">
              <Zap className="w-3 h-3" /> Platform Capabilities
            </div>
            <h2 className="text-[30px] font-black tracking-[-0.025em] text-white mb-2.5">
              Not Just Detection —<br />
              <span className="gradient-text">Complete Protection</span>
            </h2>
            <p className="text-[13px] text-slate-500 leading-relaxed max-w-[440px] mx-auto">
              Kavach goes beyond flagging threats. It educates, guides, and empowers you to become scam-proof.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {features.map((f) => (
              <div key={f.title}
                className="p-5 bg-[#060B18] border border-[#1E2A45] rounded-[14px] transition-all hover:border-blue-600/30 hover:-translate-y-0.5 hover:shadow-[0_4px_24px_rgba(37,99,235,0.1)] group cursor-pointer">
                <div className="w-[38px] h-[38px] rounded-[10px] flex items-center justify-center mb-3.5 flex-shrink-0 transition-transform group-hover:scale-105" style={{ background: f.iconBg }}>
                  {f.icon}
                </div>
                <h3 className="text-[14px] font-bold text-white mb-1.5">{f.title}</h3>
                <p className="text-[12px] text-slate-500 leading-relaxed">{f.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── LIVE PRODUCT PREVIEW ── */}
      <section className="py-16 px-8 bg-[#060B18] border-b border-[#101828]">
        <div className="max-w-[900px] mx-auto">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-1.5 bg-emerald-600/10 border border-emerald-600/22 rounded-full px-3 py-1 text-[10px] font-bold text-emerald-300 tracking-[0.07em] uppercase mb-3">
              <Zap className="w-3 h-3" /> Live Demo
            </div>
            <h2 className="text-[30px] font-black tracking-[-0.025em] text-white mb-2.5">
              See Kavach in Action
            </h2>
            <p className="text-[13px] text-slate-500 leading-relaxed max-w-[440px] mx-auto">
              Try a real scam analysis without leaving this page. Watch Kavach detect, decode, and explain a live scam attempt.
            </p>
          </div>
          <LivePreview />
        </div>
      </section>

      {/* ── SCAM TYPES ── */}
      <section className="py-14 px-8 bg-[#0A101F] border-b border-[#101828]">
        <div className="max-w-[900px] mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-[26px] font-black tracking-tight text-white mb-2">
              Scam Types We <span className="gradient-text">Detect & Expose</span>
            </h2>
            <p className="text-[12px] text-slate-500">Kavach is trained on the most common scams targeting India and South Asia</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {scamTypes.map((s) => (
              <div key={s.label} className="flex items-center justify-between px-4 py-3 rounded-[10px] bg-white/[0.025] border border-white/[0.07] hover:bg-white/[0.04] transition-colors">
                <span className="text-[12px] text-slate-300 font-medium">{s.label}</span>
                <span className="text-[9px] font-bold px-2 py-0.5 rounded-full" style={{ color: s.color, background: `${s.color}18`, border: `1px solid ${s.color}35` }}>
                  {s.tag}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-16 px-8 bg-[#060B18] border-b border-[#101828]">
        <div className="max-w-[720px] mx-auto">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-1.5 bg-blue-600/10 border border-blue-600/22 rounded-full px-3 py-1 text-[10px] font-bold text-blue-300 tracking-[0.07em] uppercase mb-3">
              FAQ
            </div>
            <h2 className="text-[28px] font-black tracking-[-0.025em] text-white mb-2">
              Questions? <span className="gradient-text">Answered.</span>
            </h2>
          </div>
          <div className="flex flex-col gap-2.5">
            {faqs.map((faq) => <FaqItem key={faq.q} q={faq.q} a={faq.a} />)}
          </div>
        </div>
      </section>

      {/* ── FOUNDER ── */}
      <section className="py-16 px-8 bg-[#0A101F] border-b border-[#101828]">
        <div className="max-w-[680px] mx-auto">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-1.5 bg-violet-600/10 border border-violet-600/22 rounded-full px-3 py-1 text-[10px] font-bold text-violet-300 tracking-[0.07em] uppercase mb-3">
              The Story Behind Kavach
            </div>
            <h2 className="text-[28px] font-black tracking-[-0.025em] text-white">
              Building Safer<br /><span className="gradient-text">Digital Experiences</span>
            </h2>
          </div>
          <div className="glass-card p-8 text-center">
            <div className="absolute left-0 right-0 h-px bg-gradient-to-r from-transparent via-blue-300/15 to-transparent top-0" />
            {/* Avatar */}
            <div className="relative w-[72px] h-[72px] mx-auto mb-5">
              <div className="absolute inset-0 rounded-full border border-blue-400/25 animate-spin-slow" />
              <div className="w-full h-full rounded-full gradient-kavach flex items-center justify-center text-[28px] font-black text-white">
                D
              </div>
            </div>
            <h3 className="text-[18px] font-black text-white mb-1">Dakshesh Saluja</h3>
            <p className="text-[12px] text-blue-400 font-semibold mb-4">Founder &amp; Developer</p>
            <p className="text-[13px] text-slate-400 leading-relaxed max-w-[480px] mx-auto mb-6">
              I built Kavach after watching people around me lose money, dignity, and peace of mind to increasingly sophisticated digital scams. The problem isn&apos;t greed or naivety — it&apos;s a lack of tools. Kavach is my answer to that gap: a free, intelligent shield that anyone can use, regardless of their technical knowledge.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2 mb-6">
              {["Cyber Safety", "AI for Social Good", "Digital Awareness", "User Protection"].map((tag) => (
                <span key={tag} className="text-[10px] px-3 py-1 rounded-full bg-white/[0.05] border border-white/[0.1] text-slate-400">{tag}</span>
              ))}
            </div>
            <div className="flex items-center justify-center gap-3">
              <a href="https://github.com" target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-2 h-[36px] px-4 bg-white/[0.06] border border-white/[0.12] rounded-[9px] text-[11px] font-semibold text-slate-300 no-underline transition-all hover:bg-white/[0.09] hover:text-white">
                <Github className="w-3.5 h-3.5" /> GitHub
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-2 h-[36px] px-4 bg-blue-600/15 border border-blue-600/30 rounded-[9px] text-[11px] font-semibold text-blue-300 no-underline transition-all hover:bg-blue-600/20">
                <Linkedin className="w-3.5 h-3.5" /> LinkedIn
              </a>
              <a href="mailto:dakshesh@kavach.ai"
                className="flex items-center gap-2 h-[36px] px-4 bg-white/[0.06] border border-white/[0.12] rounded-[9px] text-[11px] font-semibold text-slate-300 no-underline transition-all hover:bg-white/[0.09] hover:text-white">
                <Mail className="w-3.5 h-3.5" /> Email
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-14 px-8 bg-[#060B18] border-b border-[#101828]">
        <div className="max-w-[640px] mx-auto text-center">
          <div className="inline-flex items-center justify-center w-14 h-14 gradient-kavach rounded-[16px] mb-5 shadow-[0_8px_32px_rgba(59,130,246,0.3)]">
            <Shield className="w-7 h-7 text-white" />
          </div>
          <h2 className="text-[32px] font-black tracking-tight text-white mb-3">
            Received a suspicious message?<br />
            <span className="gradient-text">Analyze it in 2 seconds.</span>
          </h2>
          <p className="text-[13px] text-slate-400 leading-relaxed mb-7 max-w-[440px] mx-auto">
            Upload a screenshot or paste text. Kavach&apos;s AI will dissect it instantly — exposing every manipulation tactic and telling you exactly what to do.
          </p>
          <Link href="/analyze">
            <button className="h-[48px] px-8 gradient-kavach rounded-[12px] text-[15px] font-black text-white flex items-center gap-2 mx-auto transition-all hover:-translate-y-px hover:shadow-[0_8px_32px_rgba(124,58,237,0.45)]">
              Start Free Analysis <ChevronRight className="w-4 h-4" />
            </button>
          </Link>
          <p className="text-[11px] text-slate-600 mt-3">Free · Instant · Private · No account needed</p>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="border-t border-[#101828] bg-[#0A101F] pt-12 pb-8 px-8">
        <div className="max-w-[920px] mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
            {/* Brand */}
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-6 h-6 gradient-kavach rounded-[6px] flex items-center justify-center">
                  <Shield className="w-3.5 h-3.5 text-white" />
                </div>
                <span className="text-[14px] font-black text-white">KAVACH</span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed mb-4">
                AI-powered scam detection for India. Free, private, and built for social impact.
              </p>
              <div className="flex gap-2">
                <a href="https://github.com" target="_blank" rel="noopener noreferrer"
                  className="w-7 h-7 bg-white/[0.05] border border-white/[0.1] rounded-[6px] flex items-center justify-center text-slate-500 hover:text-white transition-colors no-underline">
                  <Github className="w-3.5 h-3.5" />
                </a>
                <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer"
                  className="w-7 h-7 bg-white/[0.05] border border-white/[0.1] rounded-[6px] flex items-center justify-center text-slate-500 hover:text-blue-400 transition-colors no-underline">
                  <Linkedin className="w-3.5 h-3.5" />
                </a>
                <a href="mailto:dakshesh@kavach.ai"
                  className="w-7 h-7 bg-white/[0.05] border border-white/[0.1] rounded-[6px] flex items-center justify-center text-slate-500 hover:text-white transition-colors no-underline">
                  <Mail className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.09em] mb-3">Quick Links</p>
              <div className="flex flex-col gap-2">
                {[
                  { label: "Home", href: "/" },
                  { label: "Analyze", href: "/analyze" },
                  { label: "Results", href: "/results" },
                  { label: "Sign In", href: "/login" },
                  { label: "Create Account", href: "/signup" },
                ].map((l) => (
                  <Link key={l.label} href={l.href} className="text-[11px] text-slate-600 hover:text-slate-400 transition-colors no-underline">{l.label}</Link>
                ))}
              </div>
            </div>

            {/* Cyber Safety Resources */}
            <div>
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.09em] mb-3">Cyber Safety</p>
              <div className="flex flex-col gap-2">
                {[
                  { label: "CERT-In", href: "https://cert-in.org.in" },
                  { label: "Cyber Crime Portal", href: "https://cybercrime.gov.in" },
                  { label: "RBI Helpline", href: "https://rbi.org.in" },
                  { label: "TRAI DND", href: "https://trai.gov.in" },
                ].map((l) => (
                  <a key={l.label} href={l.href} target="_blank" rel="noopener noreferrer"
                    className="text-[11px] text-slate-600 hover:text-slate-400 transition-colors no-underline flex items-center gap-1">
                    {l.label} <ExternalLink className="w-2.5 h-2.5 opacity-50" />
                  </a>
                ))}
              </div>
            </div>

            {/* Contact */}
            <div>
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.09em] mb-3">Contact</p>
              <div className="flex flex-col gap-2">
                <a href="mailto:dakshesh@kavach.ai" className="text-[11px] text-slate-600 hover:text-slate-400 transition-colors no-underline">dakshesh@kavach.ai</a>
                <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-[11px] text-slate-600 hover:text-slate-400 transition-colors no-underline flex items-center gap-1">
                  GitHub <ExternalLink className="w-2.5 h-2.5 opacity-50" />
                </a>
                <span className="text-[11px] text-slate-700">Privacy Policy</span>
              </div>
            </div>
          </div>

          <div className="border-t border-[#101828] pt-6 flex flex-col md:flex-row items-center justify-between gap-3">
            <p className="text-[11px] text-slate-700">
              © 2025 Kavach · Built by <span className="text-slate-500 font-semibold">Dakshesh Saluja</span> · AI for Social Impact
            </p>
            <p className="text-[11px] text-slate-700">
              Protecting India from digital scams · Made with ❤️ in India 🇮🇳
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
