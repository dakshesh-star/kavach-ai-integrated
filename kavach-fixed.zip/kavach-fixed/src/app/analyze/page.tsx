"use client";

import { useState, useRef, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Upload, Image, FileText, Link, Mic, X, Shield, Zap, AlertTriangle, CheckCircle } from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { cn } from "@/lib/utils";

type TabId = "screenshot" | "paste" | "url" | "voice";

const tabs: { id: TabId; label: string; icon: React.ReactNode; iconBg: string }[] = [
  { id: "screenshot", label: "Screenshot", icon: <Image className="w-3 h-3" />, iconBg: "rgba(59,130,246,0.18)" },
  { id: "paste", label: "Paste Message", icon: <FileText className="w-3 h-3" />, iconBg: "rgba(124,58,237,0.18)" },
  { id: "url", label: "Suspicious URL", icon: <Link className="w-3 h-3" />, iconBg: "rgba(14,165,233,0.18)" },
  { id: "voice", label: "Voice/Call", icon: <Mic className="w-3 h-3" />, iconBg: "rgba(34,197,94,0.18)" },
];

const analysisSteps = [
  { label: "Analyzing Threat Patterns...", duration: 600 },
  { label: "Detecting Manipulation Techniques...", duration: 700 },
  { label: "Checking Scam Signatures...", duration: 800 },
  { label: "Evaluating Risk Factors...", duration: 500 },
  { label: "Generating Recovery Guidance...", duration: 400 },
];

export default function AnalyzePage() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [activeTab, setActiveTab] = useState<TabId>("screenshot");
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [pastedText, setPastedText] = useState("");
  const [urlInput, setUrlInput] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisStep, setAnalysisStep] = useState(0);
  const [analysisLabel, setAnalysisLabel] = useState("");
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const handleFile = (file: File) => {
    setUploadedFile(file);
    if (file.type.startsWith("image/")) {
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    } else {
      setPreviewUrl(null);
    }
  };

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, []);

  const canAnalyze = () => {
    if (activeTab === "screenshot") return !!uploadedFile;
    if (activeTab === "paste") return pastedText.trim().length > 10;
    if (activeTab === "url") return urlInput.trim().length > 3;
    return false;
  };

  const runAnalysis = async () => {
    if (!canAnalyze() || isAnalyzing) return;
    setIsAnalyzing(true);
    setError(null);
    setAnalysisProgress(0);

    // Start step animation loop (runs in parallel with API call)
    let stepIndex = 0;
    const stepInterval = setInterval(() => {
      if (stepIndex < analysisSteps.length) {
        setAnalysisStep(stepIndex);
        setAnalysisLabel(analysisSteps[stepIndex].label);
        setAnalysisProgress(Math.round(((stepIndex + 0.5) / analysisSteps.length) * 90));
        stepIndex++;
      }
    }, 700);

    try {
      let response: Response;

      if (activeTab === "screenshot" && uploadedFile) {
        const formData = new FormData();
        formData.append("file", uploadedFile);
        response = await fetch("/api/analyze", {
          method: "POST",
          body: formData,
        });
      } else {
        response = await fetch("/api/analyze", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            type: activeTab,
            content: activeTab === "url" ? urlInput : pastedText,
          }),
        });
      }

      clearInterval(stepInterval);

      const json = await response.json() as { success?: boolean; data?: unknown; error?: string };

      if (!response.ok || !json.success) {
        throw new Error(json.error ?? "Analysis failed. Please try again.");
      }

      // Store result for results page
      sessionStorage.setItem("kavach_result", JSON.stringify(json.data));

      // Complete progress animation
      setAnalysisProgress(100);
      setAnalysisLabel("Analysis Complete!");
      await new Promise((r) => setTimeout(r, 500));

      router.push("/results");
    } catch (err: unknown) {
      clearInterval(stepInterval);
      setIsAnalyzing(false);
      setAnalysisProgress(0);
      const message = err instanceof Error ? err.message : "Something went wrong. Please try again.";
      setError(message);
    }
  };

  const clearFile = () => {
    setUploadedFile(null);
    setPreviewUrl(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  return (
    <div className="min-h-screen bg-[#060B18]">
      <Navbar />

      {/* Loading Overlay */}
      {isAnalyzing && (
        <div className="fixed inset-0 z-50 bg-[#060B18]/95 backdrop-blur-sm flex flex-col items-center justify-center">
          <div className="relative w-[120px] h-[120px] flex items-center justify-center mb-8">
            <div className="absolute w-[100px] h-[100px] rounded-full border border-blue-400/20 animate-spin-slow" />
            <div className="absolute w-[120px] h-[120px] rounded-full border border-violet-400/15 animate-spin-slow-r" />
            {[0, 1.2, 2.4].map((d, i) => (
              <div key={i} className="absolute top-1/2 left-1/2 rounded-full border border-blue-300/20"
                style={{ width: "80px", height: "80px", animation: `ripout 3s ease-out ${d}s infinite`, transform: "translate(-50%,-50%) scale(0.4)" }} />
            ))}
            <div className="animate-breathe z-10">
              <div className="w-[52px] h-[52px] gradient-kavach rounded-[14px] flex items-center justify-center">
                <Shield className="w-7 h-7 text-white" strokeWidth={1.5} />
              </div>
            </div>
          </div>

          <div className="text-center mb-8">
            <h3 className="text-[18px] font-black text-white mb-1">Kavach AI Analyzing</h3>
            <p className="text-[13px] text-slate-400">{analysisLabel}</p>
          </div>

          <div className="w-[320px]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] text-slate-500">{analysisSteps[analysisStep]?.label}</span>
              <span className="text-[11px] font-bold text-blue-400">{analysisProgress}%</span>
            </div>
            <div className="h-[4px] bg-white/[0.07] rounded-full overflow-hidden">
              <div className="h-full gradient-kavach rounded-full transition-all duration-500" style={{ width: `${analysisProgress}%` }} />
            </div>
            <div className="flex gap-2 mt-4">
              {analysisSteps.map((_, i) => (
                <div key={i} className={cn("flex-1 h-[3px] rounded-full transition-all duration-300", i <= analysisStep ? "gradient-kavach" : "bg-white/[0.07]")} />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute grid-overlay inset-0" />
        <div className="absolute -top-[120px] left-1/2 -translate-x-1/2 w-[800px] h-[560px] rounded-full animate-glow-pulse"
          style={{ background: "radial-gradient(ellipse, rgba(30,64,175,0.2) 0%, transparent 60%)" }} />
      </div>

      <div className="relative z-10 max-w-[820px] mx-auto px-6 pt-12 pb-16">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-blue-600/10 border border-blue-600/22 rounded-full px-3.5 py-1.5 text-[10px] font-bold text-blue-300 tracking-[0.07em] uppercase mb-5 animate-fade-slide">
            <Zap className="w-3 h-3" /> AI Scam Intelligence Engine
          </div>
          <h1 className="text-[44px] font-black leading-[1.04] tracking-[-0.04em] text-white mb-3" style={{ animation: "fadeSlide 0.6s 0.1s ease-out both", opacity: 0 }}>
            Analyze Any<br />
            <span className="gradient-text animate-shimmer">Suspicious Content</span>
          </h1>
          <p className="text-[14px] text-slate-500 leading-relaxed max-w-[460px] mx-auto" style={{ animation: "fadeSlide 0.6s 0.2s ease-out both", opacity: 0 }}>
            Upload a screenshot, paste a message, or drop a URL. Kavach decodes scam tactics in seconds.
          </p>
        </div>

        {/* Tab Selector */}
        <div className="flex justify-center gap-1.5 mb-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id); setError(null); }}
              className={cn(
                "flex items-center gap-2 px-4 py-2.5 rounded-[11px] border text-[12px] font-semibold transition-all",
                activeTab === tab.id
                  ? "bg-blue-600/12 border-blue-600/38 text-blue-300 shadow-[0_4px_20px_rgba(37,99,235,0.12)]"
                  : "bg-white/[0.025] border-[#1A2740] text-slate-500 hover:border-blue-400/20 hover:text-slate-400 hover:-translate-y-px"
              )}
            >
              <span className={cn("w-[22px] h-[22px] rounded-[6px] flex items-center justify-center")} style={{ background: tab.iconBg }}>
                {tab.icon}
              </span>
              {tab.label}
            </button>
          ))}
        </div>

        {/* Upload Zone */}
        <div className="bg-[#060B18] border border-[#1E2A45] rounded-[20px] overflow-hidden mb-5">
          {/* Tab: Screenshot */}
          {activeTab === "screenshot" && (
            <div className="p-6">
              {!uploadedFile ? (
                <div
                  onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
                  onDragLeave={() => setIsDragOver(false)}
                  onDrop={onDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={cn(
                    "border-2 border-dashed rounded-[14px] p-10 text-center cursor-pointer transition-all",
                    isDragOver
                      ? "border-blue-400/60 bg-blue-600/[0.06] shadow-[0_0_0_4px_rgba(37,99,235,0.08)]"
                      : "border-[#1E2A45] hover:border-blue-400/35 hover:bg-white/[0.02]"
                  )}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*,.pdf"
                    className="hidden"
                    onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
                  />
                  <div className={cn("w-[52px] h-[52px] rounded-[14px] flex items-center justify-center mx-auto mb-4 transition-all", isDragOver ? "gradient-kavach" : "bg-white/[0.05]")}>
                    <Upload className={cn("w-6 h-6 transition-colors", isDragOver ? "text-white" : "text-blue-400")} />
                  </div>
                  <p className="text-[15px] font-bold text-white mb-1.5">
                    {isDragOver ? "Drop it here" : "Drop screenshot or click to upload"}
                  </p>
                  <p className="text-[12px] text-slate-500 mb-1">Supports PNG, JPG, WEBP, PDF · Max 10MB</p>
                  <p className="text-[11px] text-slate-600 mb-4">Include the sender&apos;s name or number in the screenshot for best accuracy</p>
                  <div className="flex gap-3 justify-center">
                    {["WhatsApp Screenshot", "SMS", "Email", "Payment App"].map((t) => (
                      <span key={t} className="text-[10px] px-2.5 py-1 bg-white/[0.04] border border-white/[0.08] rounded-full text-slate-400">{t}</span>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="relative">
                  {previewUrl ? (
                    <div className="relative rounded-[12px] overflow-hidden bg-black/40 border border-white/[0.08]">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={previewUrl} alt="Preview" className="w-full max-h-[320px] object-contain" />
                    </div>
                  ) : (
                    <div className="flex items-center gap-3 p-4 bg-white/[0.04] border border-white/[0.08] rounded-[12px]">
                      <FileText className="w-8 h-8 text-blue-400" />
                      <div>
                        <p className="text-[13px] font-semibold text-white">{uploadedFile.name}</p>
                        <p className="text-[11px] text-slate-500">{(uploadedFile.size / 1024).toFixed(1)} KB</p>
                      </div>
                    </div>
                  )}
                  <button
                    onClick={clearFile}
                    className="absolute top-3 right-3 w-7 h-7 bg-black/60 border border-white/[0.12] rounded-full flex items-center justify-center hover:bg-red-500/30 transition-colors"
                  >
                    <X className="w-3.5 h-3.5 text-white" />
                  </button>
                  <div className="flex items-center gap-2 mt-3 p-2.5 bg-emerald-500/[0.06] border border-emerald-500/15 rounded-[10px]">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-[11px] text-emerald-400">File ready for analysis</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Tab: Paste */}
          {activeTab === "paste" && (
            <div className="p-6">
              <p className="text-[12px] text-slate-500 mb-3">Paste the full message — more context means more accurate analysis</p>
              <div className="relative">
                <textarea
                  value={pastedText}
                  onChange={(e) => setPastedText(e.target.value)}
                  placeholder="Paste the suspicious message, email, or text here...

Example: 'Dear Customer, Your KYC verification is pending. Complete within 24 hours or your account will be frozen. Click here: bit.ly/xyz123'"
                  rows={8}
                  className="w-full bg-white/[0.04] border border-[#1E2A45] rounded-[12px] p-4 text-[13px] text-white/85 placeholder-slate-600 resize-none outline-none focus:border-blue-400/55 focus:shadow-[0_0_0_3px_rgba(59,130,246,0.12)] transition-all leading-relaxed"
                />
                {pastedText.length > 0 && (
                  <button onClick={() => setPastedText("")} className="absolute top-3 right-3 w-6 h-6 flex items-center justify-center hover:text-red-400 text-slate-600 transition-colors">
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              <div className="flex items-center justify-between mt-2">
                <span className="text-[10px] text-slate-600">{pastedText.length} characters</span>
                {pastedText.length > 0 && pastedText.length <= 10 && (
                  <span className="text-[10px] text-yellow-400 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" /> Add more context for accurate results
                  </span>
                )}
                {pastedText.length > 10 && (
                  <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" /> Ready to analyze
                  </span>
                )}
              </div>
            </div>
          )}

          {/* Tab: URL */}
          {activeTab === "url" && (
            <div className="p-6">
              <p className="text-[12px] text-slate-500 mb-3">Paste a suspicious link or phone number to check</p>
              <div className="relative">
                <Link className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-400/50" />
                <input
                  type="text"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  placeholder="https://suspicious-link.com or phone number..."
                  className="w-full h-[48px] bg-white/[0.04] border border-[#1E2A45] rounded-[12px] pl-10 pr-4 text-[13px] text-white/85 placeholder-slate-600 outline-none focus:border-blue-400/55 focus:shadow-[0_0_0_3px_rgba(59,130,246,0.12)] transition-all"
                />
              </div>
              <div className="flex flex-wrap gap-2 mt-3">
                {["bit.ly/xyz", "t.me/reward_claim", "+91 9876543210", "rbi-kyc.in"].map((ex) => (
                  <button key={ex} onClick={() => setUrlInput(ex)}
                    className="text-[10px] px-2.5 py-1 bg-white/[0.04] border border-white/[0.08] rounded-full text-slate-400 hover:text-blue-400 hover:border-blue-400/30 transition-colors">
                    {ex}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Tab: Voice */}
          {activeTab === "voice" && (
            <div className="p-10 text-center">
              <div className="w-[60px] h-[60px] bg-white/[0.05] border border-white/[0.1] rounded-full flex items-center justify-center mx-auto mb-4">
                <Mic className="w-7 h-7 text-slate-500" />
              </div>
              <p className="text-[14px] font-semibold text-white mb-1.5">Voice Analysis</p>
              <p className="text-[12px] text-slate-500 mb-4">Record or upload a suspicious call for analysis</p>
              <div className="inline-flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/25 rounded-full px-3 py-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-yellow-400" />
                <span className="text-[11px] text-yellow-400 font-medium">Coming in V2 — Q3 2025</span>
              </div>
            </div>
          )}
        </div>

        {/* Error message */}
        {error && (
          <div className="flex items-start gap-3 p-4 mb-5 bg-red-500/[0.08] border border-red-500/25 rounded-[12px]">
            <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-[13px] font-semibold text-red-300 mb-0.5">Analysis Failed</p>
              <p className="text-[12px] text-red-400/80">{error}</p>
            </div>
          </div>
        )}

        {/* Analyze Button */}
        <button
          onClick={runAnalysis}
          disabled={!canAnalyze() || isAnalyzing}
          className={cn(
            "w-full h-[52px] gradient-kavach rounded-[14px] text-[15px] font-black text-white flex items-center justify-center gap-3 transition-all",
            canAnalyze() && !isAnalyzing
              ? "hover:-translate-y-0.5 hover:shadow-[0_8px_32px_rgba(124,58,237,0.45)] cursor-pointer"
              : "opacity-40 cursor-not-allowed"
          )}
        >
          <Shield className="w-5 h-5" />
          Analyze with Kavach AI
          <Zap className="w-4 h-4 opacity-70" />
        </button>

        {canAnalyze() && (
          <p className="text-center text-[11px] text-slate-600 mt-2.5">
            Analysis typically completes in 3–8 seconds · 100% private
          </p>
        )}

        {/* Tips */}
        <div className="mt-8 p-5 bg-[#060B18] border border-[#1E2A45] rounded-[14px]">
          <p className="text-[11px] font-bold text-slate-400 mb-3 uppercase tracking-[0.07em]">Tips for best results</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {[
              { icon: "📸", tip: "Full screenshot with sender info visible gives highest accuracy" },
              { icon: "🔗", tip: "Include the full URL — even shortened links reveal threat patterns" },
              { icon: "📝", tip: "Include the complete message, not just part of it" },
            ].map((t) => (
              <div key={t.tip} className="flex items-start gap-2">
                <span className="text-[14px] mt-0.5">{t.icon}</span>
                <p className="text-[11px] text-slate-500 leading-relaxed">{t.tip}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
