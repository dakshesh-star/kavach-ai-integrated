"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import {
  Shield, AlertTriangle, CheckCircle, ChevronRight, ExternalLink,
  Brain, Zap, Eye, RefreshCw, ArrowLeft
} from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { mockAnalysisResult, AnalysisResult } from "@/data/mockResults";
import { cn } from "@/lib/utils";

const riskColors: Record<string, { text: string; bg: string; border: string; glow: string }> = {
  CRITICAL: { text: "#EF4444", bg: "rgba(220,38,38,0.1)", border: "rgba(220,38,38,0.35)", glow: "rgba(220,38,38,0.25)" },
  HIGH: { text: "#F97316", bg: "rgba(249,115,22,0.1)", border: "rgba(249,115,22,0.35)", glow: "rgba(249,115,22,0.2)" },
  MEDIUM: { text: "#F59E0B", bg: "rgba(245,158,11,0.1)", border: "rgba(245,158,11,0.3)", glow: "rgba(245,158,11,0.15)" },
  LOW: { text: "#22C55E", bg: "rgba(34,197,94,0.08)", border: "rgba(34,197,94,0.25)", glow: "rgba(34,197,94,0.12)" },
  SAFE: { text: "#10B981", bg: "rgba(16,185,129,0.08)", border: "rgba(16,185,129,0.25)", glow: "rgba(16,185,129,0.12)" },
};

const urgencyColor = {
  immediate: { text: "#EF4444", bg: "rgba(220,38,38,0.1)", border: "rgba(220,38,38,0.25)" },
  today: { text: "#F97316", bg: "rgba(249,115,22,0.08)", border: "rgba(249,115,22,0.2)" },
  "this-week": { text: "#F59E0B", bg: "rgba(245,158,11,0.08)", border: "rgba(245,158,11,0.2)" },
};

export default function ResultsPage() {
  const [data, setData] = useState<AnalysisResult>(mockAnalysisResult);
  const [isLive, setIsLive] = useState(false);
  const [scoreVisible, setScoreVisible] = useState(false);
  const [barsVisible, setBarsVisible] = useState(false);

  useEffect(() => {
    // Try to load real Gemini result from sessionStorage
    try {
      const stored = sessionStorage.getItem("kavach_result");
      if (stored) {
        const parsed = JSON.parse(stored) as AnalysisResult;
        setData(parsed);
        setIsLive(true);
        // Clear after reading so refreshing shows mock
        sessionStorage.removeItem("kavach_result");
      }
    } catch {
      // Fall through to mock data
    }

    const t1 = setTimeout(() => setScoreVisible(true), 300);
    const t2 = setTimeout(() => setBarsVisible(true), 700);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);

  const colors = riskColors[data.riskLevel] ?? riskColors.HIGH;

  return (
    <div className="min-h-screen bg-[#060B18]">
      <Navbar />

      {/* Background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute grid-overlay inset-0" />
        <div className="absolute -top-[120px] left-1/2 -translate-x-1/2 w-[800px] h-[560px] rounded-full animate-glow-pulse"
          style={{ background: "radial-gradient(ellipse, rgba(30,64,175,0.14) 0%, transparent 60%)" }} />
        <div className="absolute top-[240px] -right-[100px] w-[400px] h-[400px] rounded-full"
          style={{ background: `radial-gradient(ellipse, ${colors.glow} 0%, transparent 65%)` }} />
      </div>

      <div className="relative z-10 max-w-[920px] mx-auto px-6 pt-10 pb-16">
        {/* Back link */}
        <div className="flex items-center justify-between mb-6">
          <Link href="/analyze" className="inline-flex items-center gap-1.5 text-[12px] text-slate-500 hover:text-slate-300 transition-colors no-underline group">
            <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
            New Analysis
          </Link>
          {!isLive && (
            <span className="text-[10px] px-2.5 py-1 bg-yellow-500/10 border border-yellow-500/25 rounded-full text-yellow-400 font-medium">
              Demo Data — Submit content to see real results
            </span>
          )}
          {isLive && (
            <span className="text-[10px] px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/25 rounded-full text-emerald-400 font-medium">
              ✓ Live Gemini Analysis
            </span>
          )}
        </div>

        {/* ── VERDICT HEADER ── */}
        <div className="relative p-7 rounded-[20px] mb-5 overflow-hidden border"
          style={{ background: colors.bg, borderColor: colors.border, boxShadow: `0 0 40px ${colors.glow}` }}>
          <div className="absolute inset-0 rounded-[20px] border-2 pointer-events-none"
            style={{ borderColor: colors.border, animation: "borderGlow 3s ease-in-out infinite" }} />

          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            {/* Left: Score + Verdict */}
            <div className="flex items-center gap-6">
              {/* Risk Score Ring */}
              <div className="relative flex-shrink-0">
                <svg width="100" height="100" viewBox="0 0 100 100" className={scoreVisible ? "" : "opacity-0"}>
                  <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="8" />
                  <circle cx="50" cy="50" r="42" fill="none"
                    stroke={colors.text} strokeWidth="8"
                    strokeDasharray={`${2 * Math.PI * 42}`}
                    strokeDashoffset={`${2 * Math.PI * 42 * (1 - data.riskScore / 100)}`}
                    strokeLinecap="round"
                    transform="rotate(-90 50 50)"
                    style={{ transition: "stroke-dashoffset 1.4s cubic-bezier(0.4,0,0.2,1)" }}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-[26px] font-black text-white leading-none">{scoreVisible ? data.riskScore : 0}</span>
                  <span className="text-[9px] text-slate-400 font-semibold uppercase tracking-[0.08em]">Risk</span>
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <AlertTriangle className="w-4 h-4" style={{ color: colors.text }} />
                  <span className="text-[11px] font-bold tracking-[0.1em] uppercase" style={{ color: colors.text }}>
                    {data.riskLevel} RISK
                  </span>
                </div>
                <h1 className="text-[22px] font-black text-white leading-tight tracking-tight mb-1">{data.verdict}</h1>
                <p className="text-[12px] text-slate-400">{data.scamType}</p>
              </div>
            </div>

            {/* Right: Metadata */}
            <div className="flex flex-col gap-2 text-right">
              <div className="text-[11px] text-slate-500">
                AI Confidence: <span className="text-white font-bold">{data.confidence}%</span>
              </div>
              <div className="text-[11px] text-slate-500">
                Model: <span className="text-slate-300">{data.analysisMetadata.model}</span>
              </div>
              <div className="text-[11px] text-slate-500">
                Patterns: <span className="text-slate-300">{data.analysisMetadata.patternsMatched} matched</span>
              </div>
              <div className="text-[11px] text-slate-500">
                Time: <span className="text-emerald-400 font-bold">{data.analysisMetadata.processingTime}</span>
              </div>
            </div>
          </div>

          {/* Scam Anatomy Sentence */}
          <div className="mt-6 p-4 rounded-[12px] border" style={{ background: "rgba(220,38,38,0.07)", borderColor: "rgba(220,38,38,0.2)" }}>
            <p className="text-[9px] font-bold text-red-400/70 tracking-[0.1em] uppercase mb-2">How this scam works</p>
            <p className="text-[13px] text-red-200/90 leading-relaxed font-medium">{data.scamAnatomy}</p>
          </div>
        </div>

        {/* ── CONFIDENCE BREAKDOWN ── */}
        <div className="p-5 bg-[#060B18] border border-[#1E2A45] rounded-[16px] mb-5">
          <p className="text-[11px] font-bold text-slate-400 uppercase tracking-[0.07em] mb-4">AI Confidence Breakdown</p>
          <div className="flex flex-col gap-3">
            {data.confidenceBreakdown.map((item) => (
              <div key={item.label} className="flex items-center gap-3">
                <span className="text-[11px] text-slate-400 w-[130px] flex-shrink-0">{item.label}</span>
                <div className="flex-1 h-[6px] bg-white/[0.06] rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-1000"
                    style={{
                      background: item.color,
                      width: barsVisible ? `${item.score}%` : "0%",
                    }}
                  />
                </div>
                <span className="text-[11px] font-bold text-white w-8 text-right">{item.score}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* ── 2-COLUMN GRID ── */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-5">
          {/* Psychological Tactics */}
          <div className="p-5 bg-[#060B18] border border-[#1E2A45] rounded-[16px]">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-[28px] h-[28px] rounded-[7px] bg-violet-600/15 flex items-center justify-center">
                <Brain className="w-3.5 h-3.5 text-violet-400" />
              </div>
              <p className="text-[12px] font-bold text-white">Scam Psychology Analysis</p>
            </div>
            <div className="flex flex-col gap-3">
              {data.psychTactics.map((t) => (
                <div key={t.name} className="p-3 bg-white/[0.03] border border-white/[0.06] rounded-[10px]">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[13px]">{t.icon}</span>
                    <span className="text-[12px] font-bold text-white">{t.name}</span>
                    <span className={cn(
                      "ml-auto text-[9px] font-bold px-2 py-0.5 rounded-full",
                      t.severity === "high" ? "bg-red-500/15 text-red-400 border border-red-500/25" : "bg-yellow-500/15 text-yellow-400 border border-yellow-500/25"
                    )}>
                      {t.severity.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-relaxed">{t.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Red Flags */}
          <div className="p-5 bg-[#060B18] border border-[#1E2A45] rounded-[16px]">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-[28px] h-[28px] rounded-[7px] bg-red-600/15 flex items-center justify-center">
                <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
              </div>
              <p className="text-[12px] font-bold text-white">Detected Red Flags</p>
            </div>
            <div className="flex flex-col gap-3">
              {data.redFlags.map((f) => (
                <div key={f.flag} className="group">
                  <div className="flex items-start gap-2.5">
                    <div className="w-4 h-4 rounded-full bg-red-500/15 border border-red-500/25 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-red-400" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="text-[12px] font-semibold text-white">{f.flag}</span>
                        <span className="text-[10px] font-bold text-red-400">{f.weight}%</span>
                      </div>
                      <p className="text-[11px] text-slate-500">{f.explanation}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── INTELLIGENCE MAP ── */}
        <div className="p-5 bg-[#060B18] border border-[#1E2A45] rounded-[16px] mb-5">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-[28px] h-[28px] rounded-[7px] bg-blue-600/15 flex items-center justify-center">
              <Eye className="w-3.5 h-3.5 text-blue-400" />
            </div>
            <p className="text-[12px] font-bold text-white">Scam Intelligence Map</p>
            <span className="ml-auto text-[10px] text-slate-500">Network visualization</span>
          </div>
          <div className="relative h-[200px] bg-[#040810] rounded-[12px] border border-white/[0.05] overflow-hidden">
            <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none">
              {data.intelligenceMap.flatMap((node) =>
                node.connections.map((targetId) => {
                  const target = data.intelligenceMap.find((n) => n.id === targetId);
                  if (!target) return null;
                  return (
                    <line key={`${node.id}-${targetId}`}
                      x1={`${node.x}%`} y1={`${node.y}%`}
                      x2={`${target.x}%`} y2={`${target.y}%`}
                      stroke="rgba(99,179,237,0.2)" strokeWidth="1.5"
                      strokeDasharray="4 4"
                    />
                  );
                })
              )}
            </svg>
            {data.intelligenceMap.map((node) => (
              <div key={node.id} className="absolute flex flex-col items-center gap-1 -translate-x-1/2 -translate-y-1/2"
                style={{ left: `${node.x}%`, top: `${node.y}%` }}>
                <div className={cn(
                  "w-8 h-8 rounded-full border-2 flex items-center justify-center text-[10px] font-bold",
                  node.type === "primary" ? "bg-red-500/20 border-red-500/50 text-red-400" :
                  node.type === "warning" ? "bg-yellow-500/20 border-yellow-500/50 text-yellow-400" :
                  "bg-blue-500/20 border-blue-500/50 text-blue-400"
                )} style={{ animation: `nodeFlash ${1.5 + Math.random()}s ease-in-out infinite` }}>
                  {node.id.toUpperCase()}
                </div>
                <span className="text-[9px] text-slate-400 font-medium whitespace-nowrap bg-black/60 px-1.5 py-0.5 rounded">{node.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* ── IMMEDIATE ACTIONS ── */}
        <div className="p-5 bg-[#060B18] border border-[#1E2A45] rounded-[16px] mb-5">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-[28px] h-[28px] rounded-[7px] bg-red-600/15 flex items-center justify-center">
              <Zap className="w-3.5 h-3.5 text-red-400" />
            </div>
            <p className="text-[12px] font-bold text-white">Immediate Action Center</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {data.immediateActions.map((action) => {
              const uc = urgencyColor[action.urgency];
              return (
                <div key={action.priority} className="p-4 rounded-[12px] border transition-all hover:border-white/15"
                  style={{ background: "rgba(255,255,255,0.02)", borderColor: "rgba(255,255,255,0.07)" }}>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full gradient-kavach flex items-center justify-center text-[12px] flex-shrink-0">
                      {action.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[12px] font-bold text-white">{action.title}</span>
                        <span className="text-[9px] font-bold px-2 py-0.5 rounded-full" style={{ color: uc.text, background: uc.bg, border: `1px solid ${uc.border}` }}>
                          {action.urgency.replace("-", " ").toUpperCase()}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 leading-relaxed">{action.description}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* ── RECOVERY GUIDANCE ── */}
        <div className="p-5 bg-[#060B18] border border-[#1E2A45] rounded-[16px] mb-5">
          <div className="flex items-center gap-2 mb-5">
            <div className="w-[28px] h-[28px] rounded-[7px] bg-emerald-600/15 flex items-center justify-center">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <p className="text-[12px] font-bold text-white">Recovery Guidance</p>
          </div>
          <div className="flex flex-col gap-4">
            {data.recoverySteps.map((step, i) => (
              <div key={step.step} className="flex gap-4" style={{ animation: `stepReveal 0.5s ${i * 0.1}s ease-out both` }}>
                <div className="flex flex-col items-center">
                  <div className="w-7 h-7 gradient-kavach rounded-full flex items-center justify-center text-[11px] font-black text-white flex-shrink-0">
                    {step.step}
                  </div>
                  {i < data.recoverySteps.length - 1 && (
                    <div className="flex-1 w-px bg-gradient-to-b from-blue-600/30 to-transparent mt-2 min-h-[16px]" />
                  )}
                </div>
                <div className="pb-4">
                  <p className="text-[13px] font-bold text-white mb-1">{step.title}</p>
                  <p className="text-[12px] text-slate-500 leading-relaxed">
                    {step.description}
                    {step.link && (
                      <> — <a href={step.link} target="_blank" rel="noopener noreferrer"
                        className="text-blue-400 hover:text-blue-300 inline-flex items-center gap-0.5 transition-colors">
                        {step.linkText} <ExternalLink className="w-3 h-3" />
                      </a></>
                    )}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── PREVENTION INSIGHTS ── */}
        <div className="p-5 bg-[#060B18] border border-[#1E2A45] rounded-[16px] mb-7">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-[28px] h-[28px] rounded-[7px] bg-sky-600/15 flex items-center justify-center">
              <Shield className="w-3.5 h-3.5 text-sky-400" />
            </div>
            <p className="text-[12px] font-bold text-white">Prevention Insights</p>
          </div>
          <div className="flex flex-col gap-2.5">
            {data.preventionInsights.map((insight, i) => (
              <div key={i} className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full bg-sky-500/15 border border-sky-500/25 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-sky-400" />
                </div>
                <p className="text-[12px] text-slate-400 leading-relaxed">{insight}</p>
              </div>
            ))}
          </div>
        </div>

        {/* ── CTA FOOTER ── */}
        <div className="text-center p-8 bg-[#060B18] border border-[#1E2A45] rounded-[20px]">
          <p className="text-[18px] font-black text-white mb-1.5">Protect someone you care about</p>
          <p className="text-[12px] text-slate-500 mb-5 max-w-[380px] mx-auto">
            Share Kavach with family members who might be vulnerable to these scam tactics.
          </p>
          <div className="flex gap-3 justify-center flex-wrap">
            <Link href="/analyze">
              <button className="h-[40px] px-5 gradient-kavach rounded-[10px] text-[13px] font-bold text-white flex items-center gap-2 transition-all hover:-translate-y-px hover:shadow-[0_6px_24px_rgba(124,58,237,0.4)]">
                <RefreshCw className="w-3.5 h-3.5" /> Analyze Another
              </button>
            </Link>
            <button className="h-[40px] px-5 bg-white/[0.05] border border-white/[0.1] rounded-[10px] text-[13px] text-white flex items-center gap-2 hover:bg-white/[0.08] transition-colors">
              <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
              Share Kavach
            </button>
            <a href="https://cybercrime.gov.in" target="_blank" rel="noopener noreferrer">
              <button className="h-[40px] px-5 bg-white/[0.05] border border-red-500/25 rounded-[10px] text-[13px] text-red-400 flex items-center gap-2 hover:bg-red-500/10 transition-colors">
                <ChevronRight className="w-3.5 h-3.5" /> Report Cybercrime
              </button>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
