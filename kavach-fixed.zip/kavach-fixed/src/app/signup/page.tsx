"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Shield, Mail, Lock, Eye, EyeOff, User, Phone,
  ChevronRight, CheckCircle, BarChart2, Clock, Star
} from "lucide-react";
import { cn } from "@/lib/utils";

const benefits = [
  { icon: <Shield className="w-4 h-4 text-blue-400" />, title: "Scam Detection", desc: "AI-powered analysis of screenshots, messages & URLs" },
  { icon: <Clock className="w-4 h-4 text-violet-400" />, title: "Analysis History", desc: "Track every threat you've analyzed, forever" },
  { icon: <BarChart2 className="w-4 h-4 text-sky-400" />, title: "Recovery Dashboard", desc: "Step-by-step guidance if you've been targeted" },
  { icon: <Star className="w-4 h-4 text-emerald-400" />, title: "Personalized Protection", desc: "Scam alerts tailored to your risk profile" },
];

interface FormData {
  name: string;
  email: string;
  mobile: string;
  password: string;
  confirmPassword: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  mobile?: string;
  password?: string;
  confirmPassword?: string;
}

export default function SignupPage() {
  const router = useRouter();
  const [form, setForm] = useState<FormData>({ name: "", email: "", mobile: "", password: "", confirmPassword: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});
  const [isLoading, setIsLoading] = useState(false);
  const [activeField, setActiveField] = useState<string | null>(null);

  const set = (field: keyof FormData) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm((p) => ({ ...p, [field]: e.target.value }));
    setErrors((p) => ({ ...p, [field]: undefined }));
  };

  const validate = (): boolean => {
    const e: FormErrors = {};
    if (!form.name.trim()) e.name = "Name is required";
    if (!form.email) e.email = "Email is required";
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = "Enter a valid email";
    if (!form.mobile) e.mobile = "Mobile number is required";
    else if (!/^\+?[0-9]{10,13}$/.test(form.mobile.replace(/\s/g, ""))) e.mobile = "Enter a valid mobile number";
    if (!form.password) e.password = "Password is required";
    else if (form.password.length < 8) e.password = "Minimum 8 characters";
    if (!form.confirmPassword) e.confirmPassword = "Please confirm your password";
    else if (form.password !== form.confirmPassword) e.confirmPassword = "Passwords do not match";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setIsLoading(true);
    await new Promise((res) => setTimeout(res, 1600));
    setIsLoading(false);
    router.push("/");
  };

  const passwordStrength = (): { label: string; color: string; width: string } => {
    const p = form.password;
    if (!p) return { label: "", color: "bg-white/10", width: "0%" };
    let score = 0;
    if (p.length >= 8) score++;
    if (/[A-Z]/.test(p)) score++;
    if (/[0-9]/.test(p)) score++;
    if (/[^a-zA-Z0-9]/.test(p)) score++;
    if (score === 1) return { label: "Weak", color: "bg-red-500", width: "25%" };
    if (score === 2) return { label: "Fair", color: "bg-yellow-400", width: "50%" };
    if (score === 3) return { label: "Good", color: "bg-blue-400", width: "75%" };
    return { label: "Strong", color: "bg-emerald-400", width: "100%" };
  };

  const strength = passwordStrength();

  const inputClass = (field: keyof FormData) =>
    cn(
      "w-full h-[46px] bg-white/[0.05] border rounded-[11px] pl-[44px] pr-4 text-[13px] text-white/85 placeholder-white/25 outline-none transition-all",
      activeField === field
        ? "border-blue-400/55 shadow-[0_0_0_3px_rgba(59,130,246,0.10)]"
        : errors[field]
        ? "border-red-500/50"
        : "border-white/10 hover:border-white/18"
    );

  return (
    <div className="min-h-screen bg-[#060B18] flex overflow-hidden relative">
      {/* Backgrounds */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-[100px] -left-[60px] w-[500px] h-[500px] rounded-full"
          style={{ background: "radial-gradient(ellipse, rgba(30,64,175,0.18) 0%, transparent 65%)", animation: "glowPulse 18s ease-in-out infinite" }} />
        <div className="absolute -bottom-[80px] -right-[60px] w-[420px] h-[420px] rounded-full"
          style={{ background: "radial-gradient(ellipse, rgba(91,33,182,0.14) 0%, transparent 65%)", animation: "glowPulse 24s ease-in-out infinite reverse" }} />
        <div className="absolute inset-0 grid-overlay pointer-events-none" />
      </div>

      {/* Left Panel */}
      <div className="hidden lg:flex w-[48%] relative flex-col justify-center px-16 py-14 z-10">
        <div className="mb-10" style={{ animation: "fadeSlide 0.5s ease-out both", opacity: 0 }}>
          <Link href="/" className="flex items-center gap-2 no-underline mb-10">
            <div className="w-7 h-7 gradient-kavach rounded-[7px] flex items-center justify-center">
              <Shield className="w-4 h-4 text-white" />
            </div>
            <span className="text-[15px] font-black text-white tracking-tight">KAVACH</span>
          </Link>
          <h1 className="text-[36px] font-black leading-[1.08] tracking-[-0.03em] text-white mb-4">
            Join the movement<br />
            <span className="gradient-text animate-shimmer">against scams</span>
          </h1>
          <p className="text-[14px] text-slate-400 leading-relaxed max-w-[360px]">
            500,000+ Indians are scammed every month. Create your free account and get the AI protection you deserve.
          </p>
        </div>

        <div className="flex flex-col gap-3" style={{ animation: "fadeSlide 0.5s 0.2s ease-out both", opacity: 0 }}>
          {benefits.map((b) => (
            <div key={b.title} className="flex items-start gap-3 p-3.5 rounded-[12px] bg-white/[0.03] border border-white/[0.07] hover:border-blue-500/20 transition-colors">
              <div className="w-8 h-8 rounded-[8px] bg-white/[0.05] flex items-center justify-center flex-shrink-0 mt-0.5">
                {b.icon}
              </div>
              <div>
                <p className="text-[12px] font-semibold text-white mb-0.5">{b.title}</p>
                <p className="text-[11px] text-slate-500">{b.desc}</p>
              </div>
              <CheckCircle className="w-4 h-4 text-emerald-400/50 flex-shrink-0 mt-1 ml-auto" />
            </div>
          ))}
        </div>

        <p className="mt-8 text-[11px] text-slate-600" style={{ animation: "fadeSlide 0.5s 0.4s ease-out both", opacity: 0 }}>
          Free forever · No credit card · Made in India 🇮🇳
        </p>
      </div>

      {/* Divider */}
      <div className="hidden lg:block absolute left-[48%] top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-blue-400/12 to-transparent" />

      {/* Right Panel — Form */}
      <div className="w-full lg:w-[52%] flex items-center justify-center p-8 z-10">
        <div className="glass-card p-8 w-full max-w-[400px]" style={{ animation: "fadeSlide 0.5s 0.1s ease-out both", opacity: 0 }}>
          <div className="absolute left-0 right-0 h-px bg-gradient-to-r from-transparent via-blue-300/20 to-transparent animate-scanline" />

          <div className="mb-6">
            <div className="flex items-center gap-2 mb-4 lg:hidden">
              <div className="w-6 h-6 gradient-kavach rounded-[6px] flex items-center justify-center">
                <Shield className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="text-[13px] font-black text-white">KAVACH</span>
            </div>
            <h2 className="text-[20px] font-black text-white tracking-tight leading-tight mb-1">Create your account</h2>
            <p className="text-[12px] text-slate-500">Free · No credit card required</p>
          </div>

          <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-3">
            {/* Name */}
            <div className="relative">
              <User className={cn("absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none transition-colors", activeField === "name" ? "text-blue-400" : "text-blue-400/45")} />
              <input type="text" placeholder="Full name" value={form.name} onChange={set("name")}
                onFocus={() => setActiveField("name")} onBlur={() => setActiveField(null)}
                className={inputClass("name")} />
              {errors.name && <p className="text-[10px] text-red-400 mt-1 ml-1">{errors.name}</p>}
            </div>

            {/* Email */}
            <div className="relative">
              <Mail className={cn("absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none transition-colors", activeField === "email" ? "text-blue-400" : "text-blue-400/45")} />
              <input type="email" placeholder="Email address" value={form.email} onChange={set("email")}
                onFocus={() => setActiveField("email")} onBlur={() => setActiveField(null)}
                className={inputClass("email")} />
              {errors.email && <p className="text-[10px] text-red-400 mt-1 ml-1">{errors.email}</p>}
            </div>

            {/* Mobile */}
            <div className="relative">
              <Phone className={cn("absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none transition-colors", activeField === "mobile" ? "text-blue-400" : "text-blue-400/45")} />
              <input type="tel" placeholder="+91 Mobile number" value={form.mobile} onChange={set("mobile")}
                onFocus={() => setActiveField("mobile")} onBlur={() => setActiveField(null)}
                className={inputClass("mobile")} />
              {errors.mobile && <p className="text-[10px] text-red-400 mt-1 ml-1">{errors.mobile}</p>}
            </div>

            {/* Password */}
            <div>
              <div className="relative">
                <Lock className={cn("absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none transition-colors", activeField === "password" ? "text-blue-400" : "text-blue-400/45")} />
                <input type={showPassword ? "text" : "password"} placeholder="Password (min. 8 chars)" value={form.password} onChange={set("password")}
                  onFocus={() => setActiveField("password")} onBlur={() => setActiveField(null)}
                  className={cn(inputClass("password"), "pr-10")} />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors">
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {form.password && (
                <div className="mt-1.5 px-0.5">
                  <div className="h-[3px] bg-white/[0.07] rounded-full overflow-hidden">
                    <div className={cn("h-full rounded-full transition-all duration-500", strength.color)} style={{ width: strength.width }} />
                  </div>
                  {strength.label && <p className="text-[10px] text-slate-500 mt-0.5">Password strength: <span className="text-white/60">{strength.label}</span></p>}
                </div>
              )}
              {errors.password && <p className="text-[10px] text-red-400 mt-1 ml-1">{errors.password}</p>}
            </div>

            {/* Confirm Password */}
            <div className="relative">
              <Lock className={cn("absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none transition-colors", activeField === "confirmPassword" ? "text-blue-400" : "text-blue-400/45")} />
              <input type={showConfirm ? "text" : "password"} placeholder="Confirm password" value={form.confirmPassword} onChange={set("confirmPassword")}
                onFocus={() => setActiveField("confirmPassword")} onBlur={() => setActiveField(null)}
                className={cn(inputClass("confirmPassword"), "pr-10")} />
              <button type="button" onClick={() => setShowConfirm(!showConfirm)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors">
                {showConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
              {errors.confirmPassword && <p className="text-[10px] text-red-400 mt-1 ml-1">{errors.confirmPassword}</p>}
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full h-[46px] gradient-kavach rounded-[12px] text-[14px] font-bold text-white flex items-center justify-center gap-2 mt-1 transition-all hover:-translate-y-px hover:shadow-[0_6px_24px_rgba(124,58,237,0.4)] disabled:opacity-70 disabled:pointer-events-none"
            >
              {isLoading ? (
                <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />Creating account...</>
              ) : (
                <>Create Free Account <ChevronRight className="w-4 h-4" /></>
              )}
            </button>
          </form>

          <p className="text-center text-[11px] text-slate-600 mt-4">
            Already have an account?{" "}
            <Link href="/login" className="text-blue-400 hover:text-blue-300 font-semibold transition-colors no-underline">Sign in</Link>
          </p>

          <p className="text-center text-[10px] text-slate-700 mt-3 leading-relaxed">
            By creating an account, you agree to our{" "}
            <span className="text-slate-500 cursor-pointer hover:text-slate-400">Terms of Service</span>
            {" "}and{" "}
            <span className="text-slate-500 cursor-pointer hover:text-slate-400">Privacy Policy</span>
          </p>
        </div>
      </div>
    </div>
  );
}
