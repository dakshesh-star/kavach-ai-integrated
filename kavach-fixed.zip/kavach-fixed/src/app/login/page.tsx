"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Shield, Mail, Lock, Eye, EyeOff, ChevronRight, Fingerprint } from "lucide-react";
import { cn } from "@/lib/utils";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});
  const [activeField, setActiveField] = useState<string | null>(null);

  const validate = () => {
    const newErrors: { email?: string; password?: string } = {};
    if (!email) newErrors.email = "Email is required";
    else if (!/\S+@\S+\.\S+/.test(email)) newErrors.email = "Enter a valid email";
    if (!password) newErrors.password = "Password is required";
    else if (password.length < 6) newErrors.password = "Minimum 6 characters";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setIsLoading(true);
    await new Promise((res) => setTimeout(res, 1500));
    setIsLoading(false);
    router.push("/");
  };

  return (
    <div className="min-h-screen bg-[#060B18] flex overflow-hidden relative">
      {/* Background Effects */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-[120px] -left-[80px] w-[500px] h-[500px] rounded-full"
          style={{ background: "radial-gradient(ellipse, rgba(30,64,175,0.22) 0%, transparent 65%)", animation: "glowPulse 20s ease-in-out infinite" }} />
        <div className="absolute -bottom-[100px] -right-[60px] w-[440px] h-[440px] rounded-full"
          style={{ background: "radial-gradient(ellipse, rgba(91,33,182,0.16) 0%, transparent 65%)", animation: "glowPulse 26s ease-in-out infinite reverse" }} />
        <div className="absolute inset-0 grid-overlay pointer-events-none" />
      </div>

      {/* Left Panel — Branding */}
      <div className="hidden lg:flex w-[55%] relative flex-col items-center justify-center px-16 py-16 z-10">
        {/* Shield Visualization */}
        <div className="relative w-[220px] h-[220px] flex items-center justify-center mb-10">
          {/* Ripple rings */}
          {[0, 1.33, 2.66].map((delay, i) => (
            <div key={i} className="absolute top-1/2 left-1/2 rounded-full border border-blue-300/30"
              style={{
                width: "160px", height: "160px",
                animation: `ripout 4s ease-out ${delay}s infinite`,
                transform: "translate(-50%, -50%) scale(0.4)",
              }} />
          ))}
          {/* Orbit rings */}
          <div className="absolute w-[170px] h-[170px] rounded-full border border-blue-400/15 animate-spin-slow" />
          <div className="absolute w-[200px] h-[200px] rounded-full border border-violet-400/10 animate-spin-slow-r" />
          {/* Shield icon */}
          <div className="animate-breathe z-10 relative">
            <div className="w-[90px] h-[90px] gradient-kavach rounded-[22px] flex items-center justify-center shadow-[0_8px_32px_rgba(59,130,246,0.35),0_2px_8px_rgba(139,92,246,0.2)]">
              <Shield className="w-12 h-12 text-white" strokeWidth={1.5} />
            </div>
          </div>
        </div>

        {/* Text */}
        <div className="text-center animate-fade-slide">
          <h1 className="text-[40px] font-black leading-[1.06] tracking-[-0.03em] text-white mb-4">
            Your AI Shield Against<br />
            <span className="gradient-text animate-shimmer">Digital Scams</span>
          </h1>
          <p className="text-[15px] text-slate-400 leading-relaxed max-w-[380px] mb-8">
            Kavach uses advanced AI to detect, analyze, and explain scam attempts — protecting you from psychological manipulation.
          </p>
        </div>

        {/* Trust badges */}
        <div className="flex gap-6 flex-wrap justify-center" style={{ animation: "fadeSlide 0.6s 0.8s ease-out both", opacity: 0 }}>
          {[
            { icon: "🛡️", text: "4.2M Patterns Analyzed" },
            { icon: "⚡", text: "1.4s Detection Speed" },
            { icon: "🇮🇳", text: "Made for India" },
          ].map((badge) => (
            <div key={badge.text} className="flex items-center gap-2 text-[11px] text-slate-500">
              <span>{badge.icon}</span>
              <span className="text-slate-400 font-medium">{badge.text}</span>
            </div>
          ))}
        </div>

        {/* Scam types ticker */}
        <div className="mt-10 flex flex-col gap-2 w-full max-w-[340px]" style={{ animation: "fadeSlide 0.6s 1s ease-out both", opacity: 0 }}>
          {[
            { type: "KYC Fraud", tag: "BLOCKED", color: "#EF4444" },
            { type: "Fake Reward Scam", tag: "DETECTED", color: "#F97316" },
            { type: "Job Offer Fraud", tag: "ANALYZED", color: "#A78BFA" },
          ].map((item) => (
            <div key={item.type} className="flex items-center justify-between px-3 py-2 rounded-lg bg-white/[0.03] border border-white/[0.07]">
              <span className="text-[11px] text-slate-400">{item.type}</span>
              <span className="text-[9px] font-bold px-2 py-0.5 rounded" style={{ color: item.color, background: `${item.color}18`, border: `1px solid ${item.color}40` }}>
                {item.tag}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Divider */}
      <div className="hidden lg:block absolute left-[55%] top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-blue-400/15 to-transparent" />

      {/* Right Panel — Login Form */}
      <div className="w-full lg:w-[45%] flex items-center justify-center p-8 z-10">
        <div className="glass-card p-9 w-full max-w-[360px]" style={{ animation: "fadeSlide 0.5s 0.15s ease-out both", opacity: 0 }}>
          {/* Scanline effect */}
          <div className="absolute left-0 right-0 h-px bg-gradient-to-r from-transparent via-blue-300/25 to-transparent animate-scanline" />

          {/* Header */}
          <div className="mb-7">
            <div className="flex items-center gap-2 mb-5">
              <div className="w-6 h-6 gradient-kavach rounded-[6px] flex items-center justify-center">
                <Shield className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="text-[13px] font-black text-white">KAVACH</span>
            </div>
            <h2 className="text-[22px] font-black text-white tracking-tight leading-tight mb-1">Welcome back</h2>
            <p className="text-[12px] text-slate-500">Sign in to your secure dashboard</p>
          </div>

          {/* Social / Quick login */}
          <button className="w-full h-[42px] flex items-center justify-center gap-2 bg-white/[0.05] border border-white/[0.1] rounded-[11px] text-[13px] text-white/80 font-medium mb-4 transition-all hover:bg-white/[0.08] hover:border-white/[0.16]">
            <Fingerprint className="w-4 h-4 text-blue-400" />
            Continue with Biometric
          </button>

          <div className="flex items-center gap-3 mb-4">
            <div className="flex-1 h-px bg-white/[0.07]" />
            <span className="text-[10px] text-slate-600 font-medium">or sign in with email</span>
            <div className="flex-1 h-px bg-white/[0.07]" />
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} noValidate>
            {/* Email */}
            <div className="relative mb-3.5">
              <Mail className={cn(
                "absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none transition-colors",
                activeField === "email" ? "text-blue-400" : "text-blue-400/50"
              )} />
              <input
                type="email"
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onFocus={() => { setActiveField("email"); setErrors((p) => ({ ...p, email: undefined })); }}
                onBlur={() => setActiveField(null)}
                className={cn(
                  "w-full h-[48px] bg-white/[0.05] border rounded-[11px] pl-[44px] pr-4 text-[14px] text-white/85 placeholder-white/25 outline-none transition-all",
                  activeField === "email"
                    ? "border-blue-400/55 shadow-[0_0_0_3px_rgba(59,130,246,0.12),inset_0_1px_0_rgba(255,255,255,0.05)]"
                    : errors.email
                    ? "border-red-500/50"
                    : "border-white/10 hover:border-white/18"
                )}
              />
              {errors.email && <p className="text-[11px] text-red-400 mt-1 ml-1">{errors.email}</p>}
            </div>

            {/* Password */}
            <div className="relative mb-5">
              <Lock className={cn(
                "absolute left-3.5 top-[24px] -translate-y-1/2 w-4 h-4 pointer-events-none transition-colors",
                activeField === "password" ? "text-blue-400" : "text-blue-400/50"
              )} />
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onFocus={() => { setActiveField("password"); setErrors((p) => ({ ...p, password: undefined })); }}
                onBlur={() => setActiveField(null)}
                className={cn(
                  "w-full h-[48px] bg-white/[0.05] border rounded-[11px] pl-[44px] pr-10 text-[14px] text-white/85 placeholder-white/25 outline-none transition-all",
                  activeField === "password"
                    ? "border-blue-400/55 shadow-[0_0_0_3px_rgba(59,130,246,0.12),inset_0_1px_0_rgba(255,255,255,0.05)]"
                    : errors.password
                    ? "border-red-500/50"
                    : "border-white/10 hover:border-white/18"
                )}
              />
              <button type="button" onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-[24px] -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors">
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
              {errors.password && <p className="text-[11px] text-red-400 mt-1 ml-1">{errors.password}</p>}
            </div>

            <div className="flex items-center justify-between mb-5">
              <label className="flex items-center gap-2 cursor-pointer">
                <div className="w-[15px] h-[15px] border border-white/15 rounded-[4px] bg-white/[0.04] flex items-center justify-center">
                  <div className="w-[8px] h-[8px] gradient-kavach rounded-[2px]" />
                </div>
                <span className="text-[11px] text-slate-500">Remember me</span>
              </label>
              <button type="button" className="text-[11px] text-blue-400 hover:text-blue-300 transition-colors">
                Forgot password?
              </button>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full h-[46px] gradient-kavach rounded-[12px] text-[14px] font-bold text-white flex items-center justify-center gap-2 transition-all hover:-translate-y-px hover:shadow-[0_6px_24px_rgba(124,58,237,0.4)] disabled:opacity-70 disabled:pointer-events-none"
            >
              {isLoading ? (
                <>
                  <div className="w-[16px] h-[16px] border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Authenticating...
                </>
              ) : (
                <>
                  Sign in to Kavach
                  <ChevronRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <p className="text-center text-[11px] text-slate-600 mt-5">
            New to Kavach?{" "}
            <Link href="/signup" className="text-blue-400 hover:text-blue-300 font-semibold transition-colors no-underline">
              Create free account
            </Link>
          </p>

          {/* Security note */}
          <div className="flex items-center gap-2 mt-5 p-2.5 rounded-lg bg-emerald-500/[0.06] border border-emerald-500/15">
            <Shield className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
            <p className="text-[10px] text-emerald-400/80">
              256-bit AES encrypted · Zero data retention
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
